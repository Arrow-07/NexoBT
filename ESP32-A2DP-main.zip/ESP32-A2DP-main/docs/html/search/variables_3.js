var searchData=
[
  ['is_5fvolume_5fused_351',['is_volume_used',['../class_a2_d_p_volume_control.html#a7982efce1f1a1ab6c902900f8e0bb696',1,'A2DPVolumeControl']]]
];
