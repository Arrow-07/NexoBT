var searchData=
[
  ['mono_5fdownmix_105',['mono_downmix',['../class_a2_d_p_volume_control.html#a8b449f76c7c931cf590732a3d73acaea',1,'A2DPVolumeControl']]]
];
